# EDUSMART-CM : modèle de données

Schéma relationnel PostgreSQL défini dans `backend/migrations/init.sql` (créé par `npm run migrate`, alimenté par `npm run seed`).

```mermaid
erDiagram
    ETABLISSEMENTS ||--o{ UTILISATEURS : emploie
    ETABLISSEMENTS ||--o{ CLASSES : compte
    ETABLISSEMENTS ||--o{ ELEVES : scolarise
    CLASSES ||--o{ ELEVES : regroupe
    UTILISATEURS ||--o{ ENSEIGNANT_CLASSES : "est affecté"
    CLASSES ||--o{ ENSEIGNANT_CLASSES : "reçoit"
    MATIERES ||--o{ ENSEIGNANT_CLASSES : "est enseignée"
    UTILISATEURS ||--o{ EVALUATIONS : crée
    CLASSES ||--o{ EVALUATIONS : "est évaluée"
    MATIERES ||--o{ EVALUATIONS : porte
    EVALUATIONS ||--o{ NOTES : contient
    ELEVES ||--o{ NOTES : obtient
    ELEVES ||--o{ ABSENCES : "est concerné"
    UTILISATEURS ||--o{ ABSENCES : enregistre
    CLASSES ||--o{ ABSENCES : "est suivie"
    ELEVES ||--o{ APPRECIATIONS : "reçoit"
    UTILISATEURS ||--o{ APPRECIATIONS : rédige
    CLASSES ||--o{ APPRECIATIONS : "est rattachée"
    UTILISATEURS ||--o{ MESSAGES : envoie
    UTILISATEURS ||--o{ MESSAGES : reçoit

    ETABLISSEMENTS { int id PK  string nom  string ville  string type }
    UTILISATEURS { int id PK  string email UK  string role  int etablissement_id FK }
    CLASSES { int id PK  string nom  string niveau  int etablissement_id FK }
    MATIERES { int id PK  string nom  int coefficient  int heures_semaine }
    ENSEIGNANT_CLASSES { int id PK  int utilisateur_id FK  int classe_id FK  int matiere_id FK  string annee_scolaire  int trimestre }
    ELEVES { int id PK  string matricule UK  int classe_id FK  int etablissement_id FK }
    EVALUATIONS { int id PK  string type  int numero  date date  int coefficient  int trimestre }
    NOTES { int id PK  int evaluation_id FK  int eleve_id FK  numeric valeur }
    ABSENCES { int id PK  int eleve_id FK  date date  string motif  string statut }
    APPRECIATIONS { int id PK  int eleve_id FK  int trimestre  text texte }
    MESSAGES { int id PK  int expediteur_id FK  int destinataire_id FK  string objet  boolean lu }
```

## Règles d'intégrité portées par la base

| Table | Règle |
|---|---|
| `utilisateurs` | e-mail unique ; rôle limité à `enseignant`, `proviseur`, `cpe`, `secretariat` |
| `enseignant_classes` | une affectation par enseignant, classe, matière et année scolaire ; trimestre 1 à 3 |
| `eleves` | matricule unique |
| `evaluations` | type limité à `DS`, `Interrogation`, `Examen` ; trimestre 1 à 3 |
| `notes` | valeur entre 0 et 20 ; une note par élève et par évaluation |
| `absences` | motif et statut limités à des listes ; une ligne par élève, enseignant, classe et date |
| `appreciations` | une appréciation par élève, enseignant, classe et trimestre ; trimestre 1 à 3 |
| toutes les clés étrangères | suppression en cascade depuis la table parente |

## Ce que le schéma n'empêche pas

Le schéma ne garantit pas que l'élève d'une note appartient à la classe de l'évaluation, ni que l'enseignant d'une évaluation est affecté à la classe, ni l'absence de doublons de personnes (même nom et prénom, matricules différents).
Ces cas sont contrôlés par l'audit `backend/audits/audit_qualite_donnees.sql` (voir la user story US-15 dans `docs/USER_STORIES.md`).
