# EDUSMART-CM : user stories et critères d'acceptation

Ce document formalise, sous forme de user stories, les fonctionnalités du portail enseignant EDUSMART-CM.
Il a été rédigé à partir du backlog technique (`backend/TASKS.md`), de la documentation d'API (`backend/API.md`)
et des règles de validation du code (`backend/src/modules/*`). Chaque critère décrit un comportement vérifiable
dans le code ou dans les tests d'intégration (`backend/tests/module0` à `module8`).

**Acteurs**

| Acteur | Rôle en base | Description |
|---|---|---|
| Enseignant | `enseignant` | Saisit les notes, fait l'appel, rédige les appréciations, échange avec l'administration |
| Proviseur (administration) | `proviseur` | Pilote l'établissement : comptes enseignants, classes, indicateurs, alertes |

Les rôles `cpe` et `secretariat` existent dans le schéma mais n'ont pas encore de fonctionnalité dédiée.

**Statuts :** Terminée = implémentée et couverte par un module de tests ; Proposée = pas encore implémentée.

---

## Epic 1 : Accès et compte

### US-01 : Se connecter
**En tant qu'**enseignant ou proviseur, **je veux** me connecter avec mon e-mail, mon mot de passe et mon établissement,
**afin d'** accéder uniquement aux données de mon établissement. *(Terminée, module 1)*

Critères d'acceptation
- Étant donné un e-mail mal formé, quand je valide le formulaire, alors la requête est refusée (400) avec le message « Email invalide ».
- Étant donné un mot de passe vide ou un établissement manquant, alors la requête est refusée (400) avec un message par champ.
- Étant donné des identifiants inconnus ou un mauvais mot de passe, alors la réponse est 401 « Email ou mot de passe incorrect », sans indiquer lequel est faux.
- Étant donné des identifiants valides, alors je reçois un jeton JWT ainsi que mon profil (nom, rôle, établissement).
- Étant donné un jeton absent ou invalide, quand j'appelle une route protégée, alors l'accès est refusé.

### US-02 : Changer mon mot de passe
**En tant qu'**utilisateur connecté, **je veux** changer mon mot de passe, **afin de** sécuriser mon compte. *(Terminée, module 7)*

Critères d'acceptation
- Étant donné un ancien mot de passe incorrect, alors la réponse est 400 « Ancien mot de passe incorrect ».
- Étant donné un nouveau mot de passe de moins de 6 caractères, alors la requête est refusée.
- Étant donné des données valides, alors le nouveau mot de passe est enregistré haché (bcrypt) et je reçois « Mot de passe modifié avec succès ».

---

## Epic 2 : Classes et évaluations

### US-03 : Consulter mes classes
**En tant qu'**enseignant, **je veux** voir les classes qui me sont affectées avec leur matière et leurs effectifs,
**afin de** choisir la classe sur laquelle travailler. *(Terminée, module 2)*

Critères d'acceptation
- Étant donné que je suis enseignant, alors la liste contient uniquement mes affectations (classe, matière, coefficient, heures par semaine, nombre d'élèves, nombre d'appréciations).
- Étant donné un autre rôle, alors l'accès à cette liste est refusé.
- Étant donné une classe inexistante, quand je demande son détail, alors la réponse est 404.
- La liste des élèves d'une classe est paginée.

### US-04 : Créer une évaluation
**En tant qu'**enseignant, **je veux** créer une évaluation (devoir surveillé, interrogation, examen) pour une de mes classes,
**afin de** saisir ensuite les notes. *(Terminée, module 3)*

Critères d'acceptation
- Le type est obligatoire et limité à `DS`, `Interrogation` ou `Examen`.
- Le numéro et le coefficient sont des entiers supérieurs ou égaux à 1 ; la date est au format ISO ; le trimestre vaut 1, 2 ou 3.
- Étant donné une classe à laquelle je ne suis pas affecté, alors la réponse est 403 « Vous n'êtes pas affecté à cette classe ».
- Étant donné des données valides, alors l'évaluation est créée (201) et rattachée à mon compte.

---

## Epic 3 : Notes

### US-05 : Saisir les notes d'une évaluation
**En tant qu'**enseignant, **je veux** saisir en une fois les notes de ma classe pour une évaluation,
**afin de** gagner du temps tout en évitant les erreurs de saisie. *(Terminée, module 3)*

Critères d'acceptation
- Chaque note est comprise entre 0 et 20 (contrôle côté API et contrainte `CHECK` en base).
- Étant donné qu'une seule note du lot est invalide, alors aucune note du lot n'est enregistrée et le message nomme l'élève concerné (400).
- Étant donné une évaluation que je n'ai pas créée, alors la réponse est 403 « Évaluation non trouvée ou accès refusé ».
- Il ne peut exister qu'une note par élève et par évaluation (contrainte d'unicité en base).

### US-06 : Corriger une note
**En tant qu'**enseignant, **je veux** modifier ou supprimer une note que j'ai saisie, **afin de** corriger une erreur. *(Terminée, module 3)*

Critères d'acceptation
- La nouvelle valeur est comprise entre 0 et 20, sinon 400.
- Étant donné une note qui ne dépend pas de mes évaluations, alors la réponse est 403 « Note non trouvée ou accès refusé ».

### US-07 : Consulter les résultats et les statistiques d'une classe
**En tant qu'**enseignant, **je veux** voir les moyennes et le classement de ma classe, filtrés par évaluation ou par trimestre,
**afin d'** analyser les résultats. *(Terminée, module 3)*

Critères d'acceptation
- Le tableau affiche, par élève, la moyenne générale et le rang.
- Les statistiques de classe donnent le nombre d'élèves, la moyenne de la classe, la meilleure note et la note la plus basse.
- Les filtres `evaluation_id` et `trimestre` sont optionnels ; la liste est paginée.

---

## Epic 4 : Absences

### US-08 : Faire l'appel
**En tant qu'**enseignant, **je veux** enregistrer les présences, absences et retards d'une classe pour une date donnée,
**afin de** suivre l'assiduité des élèves. *(Terminée, module 4)*

Critères d'acceptation
- La date est au format ISO et la liste des présences contient au moins un élève.
- Le statut de chaque élève vaut `present`, `absent` ou `retard`.
- Étant donné une classe à laquelle je ne suis pas affecté, alors la réponse est 403.
- Il ne peut exister qu'une ligne par élève, par enseignant, par classe et par date (contrainte d'unicité en base).
- Le motif d'absence est limité à : sans motif, maladie, retard, départ anticipé.

### US-09 : Consulter les absences
**En tant qu'**enseignant, **je veux** consulter les absences d'une classe ou d'un élève, avec des statistiques,
**afin de** repérer les élèves absents de façon répétée. *(Terminée, module 4)*

---

## Epic 5 : Appréciations

### US-10 : Rédiger l'appréciation trimestrielle d'un élève
**En tant qu'**enseignant, **je veux** rédiger puis modifier l'appréciation d'un élève pour un trimestre,
**afin de** compléter le bulletin. *(Terminée, module 5)*

Critères d'acceptation
- Le texte compte entre 5 et 1000 caractères ; le trimestre vaut 1, 2 ou 3.
- Il ne peut exister qu'une appréciation par élève, par classe, par enseignant et par trimestre (contrainte d'unicité en base).
- Je peux modifier mon appréciation (texte de 5 à 1000 caractères).

---

## Epic 6 : Messagerie

### US-11 : Échanger avec l'administration
**En tant qu'**enseignant, **je veux** envoyer et recevoir des messages, **afin de** communiquer avec l'administration
sans quitter le portail. *(Terminée, module 6)*

Critères d'acceptation
- L'objet compte de 1 à 300 caractères et le corps n'est pas vide ; le destinataire est obligatoire.
- Ma boîte de réception et mes messages envoyés sont consultables, avec pagination.
- Le nombre de messages non lus est disponible.
- Je peux supprimer un message.
- La liste des contacts disponibles est accessible depuis le portail.

---

## Epic 7 : Pilotage par l'administration

### US-12 : Suivre les indicateurs de l'établissement
**En tant que** proviseur, **je veux** voir les indicateurs de mon établissement (enseignants, élèves, classes),
**afin de** piloter l'activité. *(Terminée, modules 7 et 8)*

Critères d'acceptation
- Les routes d'administration sont réservées au rôle `proviseur` ; un enseignant n'y a pas accès.
- Les compteurs ne portent que sur mon établissement.

### US-13 : Créer des comptes enseignants et des classes
**En tant que** proviseur, **je veux** créer un compte enseignant et une classe, **afin d'** organiser l'établissement. *(Terminée, module 7)*

Critères d'acceptation
- Compte enseignant : nom et prénom d'au moins 2 caractères, e-mail valide, mot de passe d'au moins 6 caractères.
- Étant donné un e-mail déjà utilisé, alors la réponse est 409 « Cet email est déjà utilisé ».
- Classe : nom et niveau d'au moins 2 caractères.

### US-14 : Être alerté des anomalies de suivi
**En tant que** proviseur, **je veux** voir le nombre d'absences non justifiées et d'enseignants dont les notes du trimestre ne sont pas saisies,
**afin d'** intervenir rapidement. *(Terminée, module 7)*

Critères d'acceptation
- Absences non justifiées : nombre d'absences au statut `absent` avec le motif `sans_motif`, pour mon établissement.
- Saisies en retard : nombre d'enseignants affectés à une classe sans aucune évaluation au trimestre 2.
- Limite connue : le message de clôture affiché dans l'alerte est un texte fixe, pas une échéance calculée.

---

## Epic 8 : Qualité des données

### US-15 : Auditer la qualité des données *(Proposée)*
**En tant que** proviseur ou administrateur de la base, **je veux** lancer un audit qui liste les incohérences de données
que le schéma ne peut pas empêcher, **afin de** les corriger avant l'édition des bulletins.

Critères d'acceptation
- L'audit est en lecture seule : il ne modifie aucune donnée.
- Il fournit une synthèse (règle, gravité, nombre d'anomalies), puis le détail (table, identifiant, description).
- Il détecte au minimum : doublons probables d'élèves, e-mails en doublon à la casse près, notes ou absences rattachées à une classe qui n'est pas celle de l'élève, évaluations sans note ou à saisie incomplète, incohérences d'établissement, appréciations hors règle.
- Sur une base sans anomalie, il ne renvoie aucune ligne.
- Mise en œuvre actuelle : script SQL `backend/audits/audit_qualite_donnees.sql` (exécution manuelle). Une route d'API et un écran dédiés restent à développer.

---

## Définition de terminé (appliquée au projet)

- Les entrées de chaque endpoint sont validées (express-validator) et les erreurs renvoient un message lisible.
- Le module est couvert par un fichier de tests (`backend/tests/moduleN.test.js`) et la CI GitHub Actions passe.
- L'endpoint est documenté dans `backend/API.md` et coché dans `backend/TASKS.md`.
